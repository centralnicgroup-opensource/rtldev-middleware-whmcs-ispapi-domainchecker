# [8.0.0](https://github.com/hexonet/whmcs-ispapi-domainchecker/compare/v7.3.3...v8.0.0) (2018-10-12)


### Bug Fixes

* **pkg:** migrated to github ([39874de](https://github.com/hexonet/whmcs-ispapi-domainchecker/commit/39874de))
* **script:** add x-bit ([7c6d072](https://github.com/hexonet/whmcs-ispapi-domainchecker/commit/7c6d072))


### BREAKING CHANGES

* **pkg:** we need to trigger a major release because of the new release process.
